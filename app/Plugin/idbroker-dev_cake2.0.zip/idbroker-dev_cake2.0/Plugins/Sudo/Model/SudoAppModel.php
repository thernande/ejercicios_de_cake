<?php
class SudoAppModel extends AppModel {
    var $name = 'Sudo';
    var $useDbConfig = 'ldap';
    var $primaryKey = 'dn';
    var $useTable = '';
    
}
?>