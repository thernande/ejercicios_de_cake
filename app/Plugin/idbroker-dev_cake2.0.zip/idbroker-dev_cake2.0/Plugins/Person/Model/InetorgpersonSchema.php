<?php
class InetorgpersonSchema extends PersonAppModel {
	var $name = 'InetorgpersonSchema';
}
?>
