<?php
class PersonAppModel extends AppModel {
    var $name = 'Person';
    var $useDbConfig = 'ldap';
    var $primaryKey = 'dn';
    var $useTable = '';
    
}
?>
