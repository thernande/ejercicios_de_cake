<?php
class DataManagersController extends IdbrokerAppController {

	var $name = 'DataManagers';    
	var $components = array('Ldap');

}
