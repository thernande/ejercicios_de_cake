<?php 
class Setting extends IdbrokerAppModel {

	var $name = 'Setting';
	var $primaryKey = 'id';     // Adapt this parameter to your data
	var $useTable = 'settings'; // Adapt this parameter to your data

}
?>
