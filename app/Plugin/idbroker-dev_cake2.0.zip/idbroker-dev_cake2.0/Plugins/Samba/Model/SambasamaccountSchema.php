<?php
class SambasamaccountSchema extends SambaAppModel {
	var $name = 'SambasamaccountSchema';
}
?>