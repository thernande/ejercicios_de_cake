<?php
	Configure::write('plugin.sudorole.label', 'Sudo Config');
	Configure::write('plugin.sudorole.name', 'sudo');
	Configure::write('plugin.sudorole.plugin', 'sudo');
?>