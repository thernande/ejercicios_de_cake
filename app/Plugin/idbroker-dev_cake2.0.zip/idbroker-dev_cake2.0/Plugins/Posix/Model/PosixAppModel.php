<?php
class PosixAppModel extends AppModel {
    var $name = 'Posix';
    var $useDbConfig = 'ldap';
    var $primaryKey = 'dn';
    var $useTable = '';
    
}
?>