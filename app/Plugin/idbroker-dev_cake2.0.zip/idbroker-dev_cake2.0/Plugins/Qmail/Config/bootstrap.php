<?php
	Configure::write('plugin.qmailuser.label', 'Qmail Settings');
	Configure::write('plugin.qmailuser.name', 'qmailuser');
	Configure::write('plugin.qmailuser.plugin', 'qmail');
?>