<?php
	Configure::write('plugin.iphost.label', 'Computer');
	Configure::write('plugin.iphost.name', 'iphost');
	Configure::write('plugin.iphost.plugin', 'computer');
?>
