<?php
class SambaAppController extends AppController {
	var $name = 'Samba';
}
?>