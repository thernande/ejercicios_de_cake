<?php
class ComputerAppModel extends AppModel {
    var $name = 'Computer';
    var $useDbConfig = 'ldap';
    var $primaryKey = 'dn';
    var $useTable = '';
    
}
?>
