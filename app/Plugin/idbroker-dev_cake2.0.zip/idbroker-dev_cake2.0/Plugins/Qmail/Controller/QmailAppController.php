<?php
class QmailAppController extends AppController {
	var $name = 'Qmail';
}
?>