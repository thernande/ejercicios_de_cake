<?php
class LdapSchema extends IdbrokerAppModel {

    var $name = 'LdapSchema';

    var $useDbConfig = 'ldap';

    var $useTable = false; // Adapt this parameter to your data

}
?>
