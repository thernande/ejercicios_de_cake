<?php
class QmailAppModel extends AppModel {
    var $name = 'Qmail';
    var $useDbConfig = 'ldap';
    var $primaryKey = 'dn';
    var $useTable = '';
    
}
?>