<?php
class SambaAppModel extends AppModel {
    var $name = 'Samba';
    var $useDbConfig = 'ldap';
    var $primaryKey = 'dn';
    var $useTable = '';
    
}
?>