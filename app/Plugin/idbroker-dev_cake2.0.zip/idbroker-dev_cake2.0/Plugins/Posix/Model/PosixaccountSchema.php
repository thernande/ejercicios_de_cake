<?php
class PosixaccountSchema extends PosixAppModel {
	var $name = 'PosixaccountSchema';
}
?>