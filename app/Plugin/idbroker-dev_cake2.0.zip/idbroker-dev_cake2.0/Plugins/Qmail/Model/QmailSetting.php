<?php
class QmailSetting extends QmailAppModel {
	var $name = 'QmailSetting';
}
?>