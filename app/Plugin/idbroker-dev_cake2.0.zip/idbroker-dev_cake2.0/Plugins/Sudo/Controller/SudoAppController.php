<?php
class SudoAppController extends AppController {
	var $name = 'Sudo';
}
?>