<?php
	Configure::write('plugin.posixaccount.label', 'Unix User');
	Configure::write('plugin.posixaccount.name', 'posixaccount');
	Configure::write('plugin.posixaccount.plugin', 'posix');
	Configure::write('plugin.posixgroup.label', 'Unix Group');
	Configure::write('plugin.posixgroup.name', 'posixgroup');
	Configure::write('plugin.posixgroup.plugin', 'posix');
?>
