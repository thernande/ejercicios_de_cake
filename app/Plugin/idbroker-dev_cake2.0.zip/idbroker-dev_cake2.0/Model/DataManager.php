<?php 
class DataManager extends IdbrokerAppModel {

	var $name = 'DataManager';
        var $useTable = array();
        var $uses = array();

}
?>
