<?php
class PosixgroupSchema extends PosixAppModel {
	var $name = 'PosixgroupSchema';
}
?>
