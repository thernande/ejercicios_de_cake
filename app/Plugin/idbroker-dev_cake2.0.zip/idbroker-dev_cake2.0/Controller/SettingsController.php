<?php
class SettingsController extends IdbrokerAppController {

	var $name = 'Settings';    

	function admin_index(){

		if(!empty($this->data)){

		}
	}
}
