<?php
	Configure::write('plugin.groupofuniquenames.label', 'LDAP Group');
	Configure::write('plugin.groupofuniquenames.name', 'groupofuniquenames');
	Configure::write('plugin.groupofuniquenames.plugin', 'uniquegroup');
?>
