<?php
class OrganizationalpersonSchema extends PersonAppModel {
	var $name = 'OrganizationalpersonSchema';
}
?>
