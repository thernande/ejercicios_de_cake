<?php
class PosixSetting extends PosixAppModel {
	var $name = 'PosixSetting';
	var $useTable = array();
	var $uses = array();
}
?>